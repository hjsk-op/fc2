# -*- coding: utf-8 -*-

class ImageType(object):
    BASE64 = 1
    OBSURL = 2
    FILE   = 3
    FACEID = 4

class VideoType(object):
    BASE64 = 1
    OBSURL = 2
    FILE   = 3
    FACEID = 4