# Huaweicloud-sdk-python-frs
Python sdk for [Face Recognization Service](https://www.huaweicloud.com/product/face.html).