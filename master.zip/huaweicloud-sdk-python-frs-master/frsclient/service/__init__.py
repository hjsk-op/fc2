from frsclient.service.service_query import ServiceQueryService
from frsclient.service.detect_service import DetectService
from frsclient.service.compare_service import CompareService
from frsclient.service.live_detect_service import LiveDetectService
from frsclient.service.search_service import SearchService
from frsclient.service.face_set_service import FaceSetService
from frsclient.service.face_service import FaceService
from frsclient.service.v2 import *
