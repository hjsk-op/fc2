from frsclient.service.v2.api_collection_v2 import ApiCollectionV2
from frsclient.service.v2.compare_service import CompareServiceV2
from frsclient.service.v2.detect_service import DetectServiceV2
from frsclient.service.v2.face_service import FaceServiceV2
from frsclient.service.v2.face_set_service import FaceSetServiceV2
from frsclient.service.v2.live_detect_service import LiveDetectServiceV2
from frsclient.service.v2.search_service import SearchServiceV2
